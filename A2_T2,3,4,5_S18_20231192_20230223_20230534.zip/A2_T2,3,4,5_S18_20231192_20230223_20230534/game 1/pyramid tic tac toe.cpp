﻿#include <iostream>
#include <cstdlib>
#include <ctime>
#include "board.h"

using namespace std;

class Player {
public:
    string name;
    char symbol;
    Player(const string& name, char symbol) : name(name), symbol(symbol) {}
    virtual void get_move(int& x, int& y) = 0;
};

class HumanPlayer : public Player {
public:
    HumanPlayer(const string& name, char symbol) : Player(name, symbol) {}
    void get_move(int& x, int& y) override {
        cin >> x >> y;
    }
};

class RandomPlayer : public Player {
public:
    RandomPlayer(const string& name, char symbol) : Player(name, symbol) {
        srand(time(0));
    }

    void get_move(int& x, int& y) override {
        x = rand() % 3;
        y = (x == 0) ? 0 : (rand() % (2 * x + 1));
        cout << name << " chooses: " << x << " " << y << endl;
    }
};

template <typename T>
class GameManager {
private:
    Board<T>* b;
    Player* p[2];
public:
    GameManager(Board<T>* board, Player* p1, Player* p2) {
        b = board;
        p[0] = p1;
        p[1] = p2;
    }

    void run() {
        int x, y;
        b->display_board();
        cout << "Welcome to Pyramid Tic-Tac-Toe!" << endl;

        while (true) {
            for (int i = 0; i < 2; i++) {
                cout << p[i]->name << "'s turn (" << p[i]->symbol << ")." << endl;
                p[i]->get_move(x, y);
                while (!b->update_board(x, y, p[i]->symbol)) {
                    cout << "Invalid move. Try again." << endl;
                    p[i]->get_move(x, y);
                }
                b->display_board();
                if (b->is_win(p[i]->symbol)) {
                    cout << p[i]->name << " wins! Congrats!" << endl;
                    return;
                }
                if (b->is_draw()) {
                    cout << "It's a draw!" << endl;
                    return;
                }
            }
        }
    }
};

int main() {
    PyramidBoard<char> board;
    int choice;
    cout << "Choose your opponent:\n1. Random Player\n2. Another Human Player\nEnter 1 or 2: ";
    cin >> choice;

    HumanPlayer p1("Player 1", 'X');
    Player* p2;

    if (choice == 1) {
        p2 = new RandomPlayer("Computer", 'O');
    }
    else {
        p2 = new HumanPlayer("Player 2", 'O');
    }

    GameManager<char> game(&board, &p1, p2);
    game.run();

    delete p2;
    return 0;
}
