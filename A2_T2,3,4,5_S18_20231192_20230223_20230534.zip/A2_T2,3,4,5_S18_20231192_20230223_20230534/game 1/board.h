#ifndef BOARD_H
#define BOARD_H

#include <iostream>
#include <vector>
#include <string>

template <typename T>
class Board {
public:
    virtual void display_board() = 0;
    virtual bool update_board(int x, int y, T symbol) = 0;
    virtual bool is_win(T symbol) = 0;
    virtual bool is_draw() = 0;
    virtual bool is_valid_move(int x, int y) = 0;
};

template <typename T>
class PyramidBoard : public Board<T> {
private:
    std::vector<std::vector<T>> b;
    int rows;

public:
    PyramidBoard() {
        rows = 3;
        b = { {T()}, {T(), T(), T()}, {T(), T(), T(), T(), T()} };
    }

    void display_board() override {
        for (size_t i = 0; i < b.size(); i++) {
            for (size_t spaces = 0; spaces < b.size() - i - 1; spaces++) {
                std::cout << "  ";
            }
            for (size_t j = 0; j < b[i].size(); j++) {
                std::cout << "[" << (b[i][j] == T() ? ' ' : b[i][j]) << "]";
            }
            std::cout << std::endl;
        }
    }

    bool update_board(int x, int y, T symbol) override {
        if (is_valid_move(x, y)) {
            b[x][y] = symbol;
            return true;
        }
        return false;
    }

    bool is_valid_move(int x, int y) override {
        return (x >= 0 && x < b.size() && y >= 0 && y < b[x].size() && b[x][y] == T());
    }

    bool is_win(T symbol) override {
        if (b[1][0] == symbol && b[1][1] == symbol && b[1][2] == symbol) return true;
        if ((b[2][0] == symbol && b[2][1] == symbol && b[2][2] == symbol) ||
            (b[2][1] == symbol && b[2][2] == symbol && b[2][3] == symbol) ||
            (b[2][2] == symbol && b[2][3] == symbol && b[2][4] == symbol)) return true;
        if (b[0][0] == symbol && b[1][0] == symbol && b[2][0] == symbol) return true;
        if (b[0][0] == symbol && b[1][1] == symbol && b[2][2] == symbol) return true;
        if (b[0][0] == symbol && b[1][2] == symbol && b[2][4] == symbol) return true;
        return false;
    }

    bool is_draw() override {
        for (size_t i = 0; i < b.size(); i++) {
            for (size_t j = 0; j < b[i].size(); j++) {
                if (b[i][j] == T()) return false;
            }
        }
        return true;
    }
};

#endif
