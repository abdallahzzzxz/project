#include <iostream>
#include "X_O_Game.h"
#include "FourInRow.h"
#include "NumericalTicTacToe.h"
#include "9x9X_O.h"
#include "5X5_tic_tac_toe.h"
#include "Misere_Classes.h"
#include "BoardGame_Classes.h"
#include "board.h"
#include "board2.h" // For Word Tic-Tac-Toe

using namespace std;

// Function declarations for each game
void playClassicTicTacToe();
void playFourInRow();
void playNumericalTicTacToe();
void playUltimateTicTacToe();
void playWordTicTacToe();
void playMisereTicTacToe();
void play5x5TicTacToe();
void play9x9TicTacToe();
void playPyramidTicTacToe();

int main() {
    int gameChoice;

    cout << "Welcome to the FCAI Multi-Game Platform!" << endl;
    cout << "Choose a game to play:" << endl;
    cout << "1. Classic Tic-Tac-Toe (X-O Game)\n";
    cout << "2. Four in a Row\n";
    cout << "3. Numerical Tic-Tac-Toe\n";
    cout << "4. Ultimate Tic-Tac-Toe\n";
    cout << "5. Word Tic-Tac-Toe\n";
    cout << "6. Mis�re Tic-Tac-Toe\n";
    cout << "7. 5x5 Tic-Tac-Toe\n";
    cout << "8. 9x9 Tic-Tac-Toe\n";
    cout << "9. Pyramid Tic-Tac-Toe\n";

    cout << "Enter your choice: ";
    cin >> gameChoice;

    switch (gameChoice) {
    case 1: playClassicTicTacToe(); break;
    case 2: playFourInRow(); break;
    case 3: playNumericalTicTacToe(); break;
    case 4: playUltimateTicTacToe(); break;
    case 5: playWordTicTacToe(); break;
    case 6: playMisereTicTacToe(); break;
    case 7: play5x5TicTacToe(); break;
    case 8: play9x9TicTacToe(); break;
    case 9: playPyramidTicTacToe(); break;
    default: cout << "Invalid choice. Exiting." << endl; return 0;
    }

    return 0;
}

// Game implementations
void playClassicTicTacToe() {
    cout << "Playing Classic Tic-Tac-Toe...\n";
    // Implementation from X_O_Game.h
}

void playFourInRow() {
    cout << "Playing Four in a Row...\n";
    // Implementation from FourInRow.h
}

void playNumericalTicTacToe() {
    cout << "Playing Numerical Tic-Tac-Toe...\n";
    // Implementation from NumericalTicTacToe.h
}

void playUltimateTicTacToe() {
    cout << "Playing Ultimate Tic-Tac-Toe...\n";
    // Placeholder for integration
}

void playWordTicTacToe() {
    cout << "Playing Word Tic-Tac-Toe...\n";
    // Implementation from word tic tac toe.cpp
}

void playMisereTicTacToe() {
    cout << "Playing Mis�re Tic-Tac-Toe...\n";
    // Implementation from Misere_Classes.h
}

void play5x5TicTacToe() {
    cout << "Playing 5x5 Tic-Tac-Toe...\n";
    // Implementation from 5X5_tic_tac_toe.h
}

void play9x9TicTacToe() {
    cout << "Playing 9x9 Tic-Tac-Toe...\n";
    // Implementation from 9x9X_O.h
}

void playPyramidTicTacToe() {
    cout << "Playing Pyramid Tic-Tac-Toe...\n";
    // Implementation from pyramid tic tac toe.cpp
}
