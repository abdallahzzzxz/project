#ifndef WORD_TIC_TAC_TOE_BOARD_H
#define _BOARDGAME_CLASSES_H

#include <iostream>
#include <vector>
#include <string>
#include <unordered_set>
#include <fstream>
#include <algorithm>

using namespace std;

template <typename T>
class Board {
protected:
    int rows, columns;
    T** board;
    int n_moves = 0;
    unordered_set<string> dictionary;

    // Helper function to convert string to lowercase
    string to_lowercase(const string& str) {
        string lower_str = str;
        transform(lower_str.begin(), lower_str.end(), lower_str.begin(), ::tolower);
        return lower_str;
    }

    // Load dictionary from file
    void load_dictionary(const string& filename) {
        ifstream file(filename);
        string word;

        if (!file.is_open()) {
            cerr << "Oops, couldn't open the dictionary file!" << endl;
            exit(1);
        }

        while (file >> word) {
            if (word.length() == 3) {
                dictionary.insert(to_lowercase(word));
            }
        }

        file.close();
    }

    // Collect all possible lines from the board
    vector<string> collect_lines() {
        vector<string> lines;

        // Rows (forward and backward)
        for (int i = 0; i < rows; i++) {
            string row_str = "";
            for (int j = 0; j < columns; j++) {
                row_str += board[i][j];
            }
            lines.push_back(row_str);
        }

        for (int i = rows - 1; i >= 0; i--) {
            string row_str = "";
            for (int j = 0; j < columns; j++) {
                row_str += board[i][j];
            }
            lines.push_back(row_str);
        }

        // Columns (forward and backward)
        for (int j = 0; j < columns; j++) {
            string col_str = "";
            for (int i = 0; i < rows; i++) {
                col_str += board[i][j];
            }
            lines.push_back(col_str);
        }

        for (int j = 0; j < columns; j++) {
            string col_str = "";
            for (int i = rows - 1; i >= 0; i--) {
                col_str += board[i][j];
            }
            lines.push_back(col_str);
        }

        // Diagonals
        string diag1 = "", diag2 = "";
        for (int i = 0; i < min(rows, columns); i++) {
            diag1 += board[i][i];
            diag2 += board[i][columns - 1 - i];
        }
        lines.push_back(diag1);
        lines.push_back(diag2);

        return lines;
    }

public:
    // Constructor
    Board(int r = 3, int c = 3, const string& dict_file = "dic.txt") :
        rows(r), columns(c), n_moves(0) {
        // Allocate 2D array dynamically
        board = new T * [rows];
        for (int i = 0; i < rows; i++) {
            board[i] = new T[columns];
            for (int j = 0; j < columns; j++) {
                board[i][j] = ' ';  // Initialize with space
            }
        }
        load_dictionary(dict_file);
    }

    // Destructor to free dynamically allocated memory
    virtual ~Board() {
        for (int i = 0; i < rows; i++) {
            delete[] board[i];
        }
        delete[] board;
    }

    // Getter methods for protected members
    int get_rows() const { return rows; }
    int get_columns() const { return columns; }
    int get_moves() const { return n_moves; }
    T get_cell(int x, int y) const {
        if (x >= 0 && x < rows && y >= 0 && y < columns) {
            return board[x][y];
        }
        throw out_of_range("Cell coordinates out of bounds");
    }

    /// Return true if move is valid and put it on the board
    /// within board boundaries in an empty cell
    /// Return false otherwise
    virtual bool update_board(int x, int y, T symbol) {
        if (x < 0 || x >= rows || y < 0 || y >= columns || board[x][y] != ' ') {
            return false;
        }
        board[x][y] = symbol;
        n_moves++;
        return true;
    }

    /// Display the board and the pieces on it
    virtual void display_board() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                cout << "[" << (board[i][j] == ' ' ? ' ' : board[i][j]) << "]";
            }
            cout << endl;
        }
    }

    /// Returns true if there is a winning word
    virtual bool is_win() {
        vector<string> lines = collect_lines();

        for (const string& line : lines) {
            if (dictionary.find(to_lowercase(line)) != dictionary.end()) {
                return true;
            }
        }

        return false;
    }

    /// Return true if all moves are done and no winner
    virtual bool is_draw() {
        return n_moves == rows * columns;
    }

    /// Return true if the game is over
    virtual bool game_is_over() {
        return is_win() || is_draw();
    }
};

#endif // WORD_TIC_TAC_TOE_BOARD_H