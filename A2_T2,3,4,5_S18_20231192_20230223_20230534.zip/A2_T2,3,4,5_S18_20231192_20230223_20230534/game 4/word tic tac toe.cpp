#include "board.h"

int main() {
    // Create a board for characters (our word game)
    Board<char> board;

    string player1_name = "Player 1";
    string player2_name = "Player 2";
    char player1_symbol = 'X';
    char player2_symbol = 'O';

    bool player1_turn = true;

    cout << "Welcome to Word Tic-Tac-Toe!" << endl;

    while (!board.game_is_over()) {
        board.display_board();

        int row, col;
        char letter;
        if (player1_turn) {
            cout << player1_name << ", it's your turn! Where do you want to play? (row, column, letter): ";
        }
        else {
            cout << player2_name << ", your turn! Where do you wanna play? (row, column, letter): ";
        }
        cin >> row >> col >> letter;

        letter = tolower(letter);

        if (!board.update_board(row, col, letter)) {
            cout << "Invalid move! Try again." << endl;
            continue;
        }

        if (board.is_win()) {
            board.display_board();
            if (player1_turn) {
                cout << player1_name << " wins! Well done!" << endl;
            }
            else {
                cout << player2_name << " wins! Nice job!" << endl;
            }
            break;
        }

        if (board.is_draw()) {
            board.display_board();
            cout << "It's a draw! Good game!" << endl;
            break;
        }

        player1_turn = !player1_turn;
    }

    return 0;
}