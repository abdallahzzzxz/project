#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "misere_classes.h"   

using namespace std;

int main() {
    srand(time(0));   

    cout << "Choose player types:\n";
    cout << "1. Human\n";
    cout << "2. Random\n";

    int choice;
    cout << "Enter player 1 type: ";
    cin >> choice;

    Player<char>* player1 = nullptr;
    if (choice == 1) {
        string name;
        cout << "Enter Player 1 name: ";
        cin >> name;
        player1 = new MiserePlayer<char>(name, 'X');
    }
    else {
        player1 = new MisereRandomPlayer<char>('X');  
    }

    cout << "Enter player 2 type: ";
    cin >> choice;

    Player<char>* player2 = nullptr;
    if (choice == 1) {
        string name;
        cout << "Enter Player 2 name: ";
        cin >> name;
        player2 = new MiserePlayer<char>(name, 'O');
    }
    else {
        player2 = new MisereRandomPlayer<char>('O');   
    }

    MisereBoard<char>* board = new MisereBoard<char>();

    player1->setBoard(board);
    player2->setBoard(board);

    Player<char>* players[2] = { player1, player2 };

    GameManager<char> gameManager(board, players);
    gameManager.run();

    board->print_loser();
     
    delete board;
    delete player1;
    delete player2;

    return 0;
}
