#ifndef _MISERETICTACTOE_CLASSES_H
#define _MISERETICTACTOE_CLASSES_H

#include "boardgame_classes.h"   

template <typename T>
class MisereBoard : public Board<T> {
public:
    MisereBoard(int rows = 3, int cols = 3) {
        this->rows = rows;
        this->columns = cols;
        this->board = new T * [rows];
        for (int i = 0; i < rows; ++i) {
            this->board[i] = new T[cols];
            for (int j = 0; j < cols; ++j) {
                this->board[i][j] = '-';   
            }
        }
    }

    bool update_board(int x, int y, T symbol) override {
        if (x >= 0 && x < this->rows && y >= 0 && y < this->columns && this->board[x][y] == '-') {
            this->board[x][y] = symbol;
            this->n_moves++;
            return true;
        }
        return false;
    }

    void display_board() override {
        cout << "   ";
        for (int j = 0; j < this->columns; ++j) {
            cout << " " << j << "  ";
        }
        cout << endl;

        for (int i = 0; i < this->rows; ++i) {
            cout << " " << i << " ";
            for (int j = 0; j < this->columns; ++j) {
                cout << "[ " << this->board[i][j] << " ] ";
            }
            cout << endl;
        }
    }

    bool is_win() override {
        for (int i = 0; i < this->rows; ++i) {
            for (int j = 0; j < this->columns; ++j) {
                if (this->board[i][j] != '-' && check_line(i, j)) {
                    return true;   
                }
            }
        }
        return false;
    }

    bool is_draw() override {
        if (this->n_moves == this->rows * this->columns) {
            return !is_win();   
        }
        return false;
    }

    bool game_is_over() override {
        return is_win() || is_draw() || this->n_moves == 9;  
    }

    void print_loser() {
        if (is_win() && this->n_moves % 2 == 0) {
            cout << "Player O loses!" << endl;
        }
        else if (is_win() && this->n_moves % 2 == 1) {
            cout << "Player X loses!" << endl;
        }
    }

private:
    bool check_line(int x, int y) {
         
        if (y <= 0 && this->board[x][y] == this->board[x][y + 1] && this->board[x][y] == this->board[x][y + 2]) return true;
        if (x <= 0 && this->board[x][y] == this->board[x + 1][y] && this->board[x][y] == this->board[x + 2][y]) return true;
        if (x <= 0 && y <= 0 && this->board[x][y] == this->board[x + 1][y + 1] && this->board[x][y] == this->board[x + 2][y + 2]) return true;
        if (x <= 0 && y >= 2 && this->board[x][y] == this->board[x + 1][y - 1] && this->board[x][y] == this->board[x + 2][y - 2]) return true;
        return false;
    }
};

template <typename T>
class MiserePlayer : public Player<T> {
public:
    MiserePlayer(std::string name, T symbol) : Player<T>(name, symbol) {}

    MiserePlayer(T symbol) : Player<T>(symbol) {}

    void getmove(int& x, int& y) override {
        cout << this->getname() << " (" << this->getsymbol() << "), enter your move (row and column): ";
        cin >> x >> y;
    }
};

template <typename T>
class MisereRandomPlayer : public Player<T> {
public:
    MisereRandomPlayer(T symbol) : Player<T>(symbol) {}

    void getmove(int& x, int& y) override {
        x = rand() % 3;
        y = rand() % 3;
    }
};

#endif
