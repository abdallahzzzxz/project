#ifndef _5X5_TIC_TAC_TOE_H
#define _5X5_TIC_TAC_TOE_H

#include "BoardGame_Classes.h"
#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
using namespace std;

template <typename T>
class FiveX5Board : public Board<T> {
private:
    int player1ThreeInARowCount = 0;
    int player2ThreeInARowCount = 0;

public:
    FiveX5Board() {
        this->rows = 5;
        this->columns = 5;
        this->n_moves = 0;

        this->board = new T * [5];
        for (int i = 0; i < 5; ++i) {
            this->board[i] = new T[5];
            for (int j = 0; j < 5; ++j)
                this->board[i][j] = '.';
        }
    }

    ~FiveX5Board() {
        for (int i = 0; i < 5; ++i)
            delete[] this->board[i];
        delete[] this->board;
    }

    bool update_board(int x, int y, T symbol) override {
        if (x >= 0 && x < 5 && y >= 0 && y < 5 && this->board[x][y] == '.') {
            this->board[x][y] = symbol;
            this->n_moves++;
            update_three_in_a_row_count(symbol);
            return true;
        }
        return false;
    }

    void display_board() override {
        cout << "Current Board:\n";
        for (int i = 0; i < 5; ++i) {
            for (int j = 0; j < 5; ++j)
                cout << this->board[i][j] << " ";
            cout << endl;
        }
    }

    bool is_win() override {
        if (player1ThreeInARowCount > player2ThreeInARowCount && game_is_over()) {
            cout << "Player 1 (X) wins with " << player1ThreeInARowCount << " three-in-a-row sequences.\n";
            return true;
        }
        else if (player2ThreeInARowCount > player1ThreeInARowCount && game_is_over()) {
            cout << "Player 2 (O) wins with " << player2ThreeInARowCount << " three-in-a-row sequences.\n";
            return true;
        }
        return false;  
    }

    bool is_draw() override {
        return this->n_moves == 24 && ! is_win();  
    }

    bool game_is_over() override {
        return this->n_moves == 24;  
    }

    int count_three_in_a_row(T symbol) {
        int count = 0;

        for (int i = 0; i < 5; ++i) {
            for (int j = 0; j < 3; ++j) {
                if (this->board[i][j] == symbol && this->board[i][j + 1] == symbol && this->board[i][j + 2] == symbol)
                    count++;
            }
        }

        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 5; ++j) {
                if (this->board[i][j] == symbol && this->board[i + 1][j] == symbol && this->board[i + 2][j] == symbol)
                    count++;
            }
        }

        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                if (this->board[i][j] == symbol && this->board[i + 1][j + 1] == symbol && this->board[i + 2][j + 2] == symbol)
                    count++;
            }
        }

        for (int i = 2; i < 5; ++i) {
            for (int j = 0; j < 3; ++j) {
                if (this->board[i][j] == symbol && this->board[i - 1][j + 1] == symbol && this->board[i - 2][j + 2] == symbol)
                    count++;
            }
        }

        return count;
    }

private:
    void update_three_in_a_row_count(T symbol) {
        if (symbol == 'X') {
            player1ThreeInARowCount = count_three_in_a_row(symbol);
        }
        else if (symbol == 'O') {
            player2ThreeInARowCount = count_three_in_a_row(symbol);
        }
    }
};


template <typename T>
class FiveX5HumanPlayer : public Player<T> {
public:
    FiveX5HumanPlayer(string n, T symbol) : Player<T>(n, symbol) {}

    void getmove(int& x, int& y) override {
        cout << this->getname() << " (" << this->getsymbol() << "), enter your move (row and column): ";
        cin >> x >> y;
    }
};
 
template <typename T>
class FiveX5RandomPlayer : public Player<T> {
public:
    FiveX5RandomPlayer(T symbol) : Player<T>("Computer", symbol) {
        srand(time(0));  
    }

    FiveX5RandomPlayer(string name, T symbol) : Player<T>(name, symbol) {
        srand(time(0)); 
    }

    void getmove(int& x, int& y) override {
        x = rand() % 5;
        y = rand() % 5;
    }
};

#endif
