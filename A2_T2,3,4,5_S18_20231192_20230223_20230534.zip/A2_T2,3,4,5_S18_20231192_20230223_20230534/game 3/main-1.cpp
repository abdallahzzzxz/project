#include <iostream>
#include "5X5_tic_tac_toe.h"

using namespace std;

int main() {
    FiveX5Board<char> board;

    Player<char>* player1;
    Player<char>* player2;

    string name1, name2;
    char symbol1, symbol2;

    cout << "Enter name for Player 1: ";
    cin >> name1;
    cout << "Choose Player 1 type (1 for Human, 2 for Random): ";
    int choice1;
    cin >> choice1;

    symbol1 = 'X';

    if (choice1 == 1) {
         
        player1 = new FiveX5HumanPlayer<char>(name1, symbol1);
    }
    else {
         
        player1 = new FiveX5RandomPlayer<char>(name1, symbol1);
    }

    cout << "Enter name for Player 2: ";
    cin >> name2;
    cout << "Choose Player 2 type (1 for Human, 2 for Random): ";
    int choice2;
    cin >> choice2;

    symbol2 = 'O';

    if (choice2 == 1) {
         
        player2 = new FiveX5HumanPlayer<char>(name2, symbol2);
    }
    else {
         
        player2 = new FiveX5RandomPlayer<char>(name2, symbol2);
    }

    player1->setBoard(&board);
    player2->setBoard(&board);

    Player<char>* players[2] = { player1, player2 };

    GameManager<char> gameManager(&board, players);

    gameManager.run();

    delete player1;
    delete player2;

    return 0;
}
